package tests

import org.junit.runner.RunWith

import org.scalatest.FlatSpec
import org.scalatest.FunSuite
import org.scalatest.junit.JUnitRunner

/**
 ********************************************************
 *  _____       _       _       ____       ____       
 * |_   _|     / \   __| __   _|  _ \ _ __|  _ \ __ _ 
 *   | |_____ / _ \ / _` \ \ / | |_) | '__| |_) / _` |
 *   | |_____/ ___ | (_| |\ V /|  __/| |  |  __| (_| |
 *   |_|    /_/   \_\__,_| \_/ |_|   |_|  |_|   \__,_|
 *
 ********************************************************
 * 
 * ScalaUnit test file for test lab 
 * 
 * @author pmudry
 * @version 1.0
 */

@RunWith(classOf[JUnitRunner])
class LaboTestJUF extends FlatSpec {
  /**
   * Test suite for question 1
   */
  import exercises.Exercise1._

  "In exercise 1, the foo method" should "return x + 1" in {
    assertResult(2) { foo(1) }
  }

  it should "work with negative values as well" in {
    assertResult(-1) { foo(-2) }
  }

  /**
   * Test suite for question 2
   */
  import exercises.Exercise2._
  
  "In exercise 1, the bar method" should "return x - 1" in {
    assertResult(0) { bar(1) }
  }

}